﻿namespace Standart.Models
{
    public class AddressRequest
    {
        public string RawAddress { get; set; }
    }

}
