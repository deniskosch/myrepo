﻿namespace Standart.Models
{
    public class AddressResponse
    {
        public string CleanedAddress { get; set; }
    }

}
